package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import util.ConnectionPool;

public class feedDAO {
	
	public static boolean insert(String id, String content) 
	throws NamingException, SQLException {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			String sql = "INSERT INTO feed (id, content) VALUES (?,?)";
			
			conn = ConnectionPool.get();
			pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);
				pstmt.setString(2, content);
				
			return (pstmt.executeUpdate()==1) ? true : false;
			
		}finally {
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		}
		
	}
	

	// 관리자용 모든 메모 보기
	public static ArrayList<feedDTO> getallList() 
			throws NamingException, SQLException {
		
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			String sql = "SELECT * FROM feed ORDER BY ts DESC";
			
			conn = ConnectionPool.get();
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();
			
			ArrayList<feedDTO> feeds = new ArrayList<feedDTO>();
			
			while(rs.next()) {
				feeds.add(new feedDTO(rs.getString(1),
									  rs.getString(2),
									  rs.getString(3),
									  rs.getString(4)));
				
				
			}
				
			return feeds;
			
		}finally {
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		}
		
	}


	//회원 자신의 메모만 보기
	public static ArrayList<feedDTO> getList(String id) 
			throws NamingException, SQLException {
		
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			String sql = "SELECT * FROM feed WHERE id = ? ORDER BY ts DESC";
			
			conn = ConnectionPool.get();
			pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);
			rs = pstmt.executeQuery();
				
			
			ArrayList<feedDTO> feeds = new ArrayList<feedDTO>();
			
			while(rs.next()) {
				feeds.add(new feedDTO(rs.getString(1),
									  rs.getString(2),
									  rs.getString(3),
									  rs.getString(4)));
				
				
			}
				
			return feeds;
			
		}finally {
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		}
		
	}
	
	//AJAX 로 모든 리스트 출력 매서드 
	public static String getListAJAX() 
			throws NamingException, SQLException {
		
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			String sql = "SELECT * FROM feed ORDER BY ts DESC";
			
			conn = ConnectionPool.get();
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();
			
			JSONArray feeds = new JSONArray();
			
			while(rs.next()) {
				JSONObject obj = new JSONObject();
				obj.put("no", rs.getString(1));
				obj.put("id", rs.getString(2));
				obj.put("content", rs.getString(3));
				obj.put("ts", rs.getString(4));
			
				feeds.add(obj);
			}
				
			return feeds.toJSONString();
			
		}finally {
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		}
		
	}

}
